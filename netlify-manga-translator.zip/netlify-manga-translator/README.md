# 만화 ZIP 번역기 (Netlify + Grok 버전)

이미지가 든 .zip을 올리면 각 페이지의 텍스트를 OCR/번역해서 다시 이미지에 그려 넣고,
번역된 .zip으로 묶어 다운로드해주는 도구입니다.
OCR/번역은 xAI Grok API(grok-4.3, 비전 지원)를 사용합니다.
API 키는 서버(Netlify Function)에만 저장되고 브라우저에는 절대 노출되지 않습니다.

## 폴더 구조
```
netlify-manga-translator/
├─ netlify.toml
├─ package.json
├─ public/
│  └─ index.html        ← 화면(프론트엔드)
└─ netlify/
   └─ functions/
      └─ translate.js   ← 서버 함수 (API 키 사용)
```

## 배포 방법 (Netlify)

1. **xAI (Grok) API 키 발급**
   - https://console.x.ai → API Keys → Create Key
   - `xai-...` 로 시작하는 키를 복사해둡니다.

2. **Netlify에 사이트 만들기**
   - https://app.netlify.com 가입/로그인
   - "Add new site" → "Deploy manually" 선택 후 이 폴더 전체를 드래그해서 올려도 되고,
     GitHub에 이 폴더를 올린 뒤 "Import from Git"으로 연결해도 됩니다.

3. **환경 변수 등록**
   - Netlify 사이트 대시보드 → Site configuration → Environment variables → Add a variable
   - Key: `XAI_API_KEY`
   - Value: 위에서 복사한 `xai-...` 키
   - 저장 후 "Deploys" 탭에서 "Trigger deploy" (재배포)를 한 번 눌러줘야 반영됩니다.

4. **접속 확인**
   - 배포된 주소(예: `https://your-site.netlify.app`)로 들어가서 zip을 업로드해봅니다.
   - `netlify.toml`이 `netlify/functions`를 함수 폴더로 지정하고 있어서,
     별도 설정 없이 `/.netlify/functions/translate` 경로로 함수가 자동 배포됩니다.

## 주의사항

- 무료 플랜 기준 Netlify Functions는 실행 시간 제한(기본 10초)이 있어서,
  이미지가 아주 많은 zip은 페이지별로 시간이 걸릴 수 있습니다. (지금 구조는 이미지 1장당 함수를 1번씩 순차 호출하므로 큰 문제는 없지만, 너무 큰 이미지는 느려질 수 있습니다.)
- xAI API는 사용량만큼 과금됩니다. console.x.ai에서 사용량/한도를 확인하세요.
- 저작권이 있는 원본 이미지를 무단으로 재배포하지 않도록 주의하세요. 이 도구는 개인적인 열람 목적의 번역 보조용입니다.

## 로컬에서 테스트하고 싶다면
```bash
npm install -g netlify-cli
cd netlify-manga-translator
netlify dev
```
`.env` 파일이나 `netlify dev` 실행 환경에 `XAI_API_KEY`를 넣어두면 로컬에서도 함수가 동작합니다.
